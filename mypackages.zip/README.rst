=============================
kannadamnistpackage in pytorch
=============================

 Trainer Class::

     from kannadamnistpackage.train import Trainer
     from kannadamnistpackage.Architectures import simple_model

